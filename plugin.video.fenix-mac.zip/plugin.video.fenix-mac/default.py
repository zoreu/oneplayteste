# -*- coding: utf-8 -*-
#------------------------------------------------------------
# KepaIPTV - XBMC Add-on by Kepa
# Version 2.1 (26.04.2021)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús y a torete (www.mimediacenter.info)


import os
import sys
try:
    from urllib.request import urlopen
    import urllib.request as urllib2
    from urllib.parse import urlparse
    import urllib.parse as urllib_
    import urllib.error
except:
    from urllib import urlopen    
    from urlparse import urlparse
    import urllib as urllib_
    import urllib2
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
import plugintools
import unicodedata
import requests
import shutil
import base64
import time
import random
PY2 = sys.version_info[0] == 2
translate = xbmc.translatePath if PY2 else xbmcvfs.translatePath

addon = xbmcaddon.Addon()
addonname = '[COLORcyan]Fenix [COLORgrey]Mac[/COLOR]'
icon = addon.getAddonInfo('icon')
myaddon = xbmcaddon.Addon("plugin.video.fenix-mac")

## Fotos
thmb_nada='https://i.imgur.com/VjSdNGq.png'
thmb_ver_canais='https://i.imgur.com/gNl9pR8.jpg'
thmb_muda_servidor='https://i.imgur.com/JKw3QKj.png'
thmb_muda_mac='https://i.imgur.com/HacX1Cu.png'
thmb_carrega_servidores='https://i.imgur.com/5idGqyQ.png'
thmb_guarda_servidores='https://i.imgur.com/tTtUI60.png'
thmb_novo_servidor='https://i.imgur.com/rlR2aeT.png'
thmb_guia='https://i.imgur.com/AIp4j2j.png'
fanny="https://i.imgur.com/gNl9pR8.jpg"
fanart_guia="https://i.imgur.com/Dbk93uX.jpg"
def run():
    #
    
    # Get params
           
    params = plugintools.get_params()
    #cambia_fondo()
    if params.get("action") is None:
        xbmc.executebuiltin('Container.SetViewMode(55)')
        main_list(params)
    else:
       
       xbmc.executebuiltin('Container.SetViewMode(55)') 
       action = params.get("action")
       url = params.get("url")
       exec (action+"(params)")

    plugintools.close_item_list()

def muda_fundo():

    foto = translate('special://home/addons/plugin.video.fenix-mac/fondo.jpg')    
    if not xbmc.getCondVisibility('Skin.String(CustomBackgroundPath)'):      
        xbmc.executebuiltin('Skin.Reset(CustomBackgroundPath)')
        xbmc.executebuiltin('Skin.SetBool(UseCustomBackground,True)')   
        xbmc.executebuiltin('Skin.SetString(CustomBackgroundPath,'+foto+')')
        xbmc.executebuiltin('ReloadSkin()')
    
def main_list(params):
    import shutil,xbmc  
    try:
        addon_path3 = translate('special://home/cache').decode('utf-8')
        shutil.rmtree(addon_path3, ignore_errors=True) 
    except:
        pass
    
    muda_fundo()
        
    escolhido=myaddon.getSetting('escolhido')
    mac=myaddon.getSetting('mac2')
    


    plugintools.log("fenix-mac.main_list ")    
    #plugintools.add_item(action="", thumbnail=thmb_nada,title="[COLOR gray]Ver Canais----------------------------------------------------------------------------[/COLOR]",folder= False )
    plugintools.add_item(action="ver_canais",    title="LISTA CANAL IPTV",thumbnail=thmb_ver_canais,fanart="fanart.png",folder= True )            

    plugintools.add_item(action="", thumbnail=thmb_nada,title="[COLOR gray]Configuração Actual--------------------------------------------------------------------------[/COLOR]",folder= False )
    plugintools.add_item(action="muda_servidor",    title="SERVIDOR Actual:   "+escolhido,thumbnail=thmb_muda_servidor,fanart="fanart.png",folder= True )               
    plugintools.add_item(action="muda_mac",         title="MAC Actual:   "+mac,thumbnail=thmb_muda_mac,fanart="fanart.png",folder= True )    
    plugintools.add_item(action="", thumbnail=thmb_nada,title="[COLOR gray]Arquivos Locais--------------------------------------------------------------------------[/COLOR]",folder= False )
    plugintools.add_item(action="carrega_servidores",    title="Lista Servidor Local",extra='Local' ,thumbnail=thmb_carrega_servidores,fanart="fanart.png",folder= True )
    plugintools.add_item(action="novo_servidor_file", extra="Local" , title="Adicionar Servidor  Local",thumbnail=thmb_novo_servidor,folder= False )
    plugintools.add_item(action="", thumbnail=thmb_nada,title="[COLOR gray]Arquivos Internet-----------------------------------------------------------------------[/COLOR]",folder= False )
    plugintools.add_item(action="novo_servidor", title="Novo Servidor Pastebin",thumbnail=thmb_novo_servidor,folder= False )
    plugintools.add_item(action="guarda_servidores",    title="Baixar Lista Servidor",extra='Internet' ,thumbnail=thmb_guarda_servidores,fanart="fanart.png",folder= False )     
    plugintools.add_item(action="carrega_servidores",    title="Lista Servidor (Descarregado)",extra='Internet' ,thumbnail=thmb_carrega_servidores,fanart="fanart.png",folder= True )         
    #plugintools.add_item(action="", thumbnail=thmb_nada,title="[COLOR gray]-------------------------------------------------------------------------[/COLOR]",folder= False )
    #plugintools.add_item(action="guiatv",url="https://www.formulatv.com/programacion/movistarplus/",title="[COLOR blue]Guia de TV[/COLOR] - (Gracias Javi R)", thumbnail=thmb_guia,fanart="http://www.panoramaaudiovisual.com/wp-content/uploads/2012/01/EPG-Toshiba-Smart-Tv-web.png",folder= True )     
    #plugintools.add_item(action="", thumbnail=thmb_nada,title="[COLOR gray]-------------------------------------------------------------------------[/COLOR]",folder= False )

def ver_canais(params):
      
    thumbnail = params.get("thumbnail")
    
    mac=myaddon.getSetting('mac2')
    portal=myaddon.getSetting('portal2')
    escolhido=myaddon.getSetting('escolhido')
    s=''
    usuario = ''
  
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain"}
    url=portal+'portal.php?type=stb&action=handshake&JsHttpRequest=1-xml'
        
    source=''
    
    try:
        source = requests.Session()
        source=requests.get(url, headers=headers).content
    except:
    
        xbmc.executebuiltin('XBMC.Notification( Não se pode ligar ao SERVIDOR: ' + escolhido +', '+portal+' '+mac+ ', 8000)')            
    
    if source =='':
        xbmc.executebuiltin('XBMC.Notification( Não se pode ligar ao  SERVIDOR: ' + escolhido +', '+str(source)+ ', 8000)')  
        #xbmc.log('ERROR conectando al servidor: '+str(source)+' : '+str(url))
        #xbmc.executebuiltin('Action(Back)')
        #return(params)
    
    token=''
    try:
        token=re.findall('token":"(.*?)"', str(source) )[0] 
    except:       
        xbmc.executebuiltin('XBMC.Notification( Não se pode ligar ao SERVIDOR: ' + escolhido +', '+str(source)+ ', 8000)')  
        #xbmc.executebuiltin('Action(Back)')
        #return(params)
    
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+str(mac)+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    url=portal+'portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
    source=""
    
    usuario=''
    
    source = requests.Session()           
    source=requests.get(url, headers=headers).content
    
    try:
        passs=re.findall('login":"","password":"(.*?)"',source )[0]
        typee=re.findall('"stb_type":"(.*?)"',str(source) )[0]
    except:
        passs=''
        usuario=''
        typee=''
            
    payload={"login":usuario,"password":passs,"stb_type":typee}
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    url=portal+'portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml'
        
    source=''
    
    s = requests.Session()                
    source=s.post(url, headers=headers,data=str(payload)).text
    
    if source!='':
        
        data = plugintools.find_multiple_matches(source,'("id":"\d+.*?".*?"title":".*?",")')   
        pr0n=myaddon.getSetting('pr0n')  
        plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False)   
        plugintools.add_item(title='[COLOR blue]ACTUAL [ '+escolhido+' # '+mac+' ][/COLOR]',folder=False, isPlayable=False)
        plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False) 
        for generos in data: 
            
            patron=plugintools.find_single_match(generos,'"id":"(\d+.*?)".*?"title":"(.*?)"') 
            titulo=patron[1]
            ids=patron[0]
                        
            tit=colorea(titulo)
            
            if  not('adult' in titulo.lower() and pr0n=="false"):                            
                plugintools.add_item(action="paginar_canais", title=tit, thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True)                         
            
    else:
        xbmc.executebuiltin('XBMC.Notification([COLOR red]Problema '+'[COLOR white]'+escolhido+'[/COLOR],[COLOR white]'+portal+' '+mac+'[/COLOR], 10000)')            
        
def muda_servidor(params):

    servidor2=myaddon.getSetting('ser')
    escolhido=myaddon.getSetting('escolhido')
    portal= myaddon.getSetting('portal2')
    mac= myaddon.getSetting('mac2')
    dialog = xbmcgui.Dialog()
    
    
    lists=myaddon.getSetting('lista').split(',')
    lista_servidores=myaddon.getSetting('lista_servidores').split(',')
    retorno = dialog.select('[COLOR blue]SERVIDOR ACTUAL: [/COLOR]'+str(escolhido), lista_servidores)
        
        #if retorno<>-1:
        #xbmc.executebuiltin('XBMC.Notification(Lista,'+lista_servidores[retorno]+',8000)')
        
    dialog = xbmcgui.Dialog()    
        
    if str(retorno)!='-1':   
        servidor2=lists[retorno]
        escolhido=lista_servidores[retorno]
        if 1==1: #try:     
            
            mac1 = str(urllib2.urlopen(urllib2.Request("https://pastebin.com/raw/"+servidor2)).read())
            
            mac=""
            mac=re.findall('(00:.*?79:.*?........)', mac1)            
            portal=re.findall('portal"(.*?)"', mac1.lower())[0]
            maclista=''
            random.seed()
            
            while maclista == '' or not maclista:
                maclista = random.choice(mac)
        
            mac=maclista                
            myaddon.setSetting('mac2',mac)
            myaddon.setSetting('portal2',portal)
            myaddon.setSetting('ser',servidor2)
            myaddon.setSetting('escolhido',escolhido)
        else:
        #except:
            xbmc.executebuiltin('XBMC.Notification( Abertura de erros: ' + str(escolhido) +', '+str(portal)+' '+str(mac)+ ', 8000)')               
            xbmc.executebuiltin('Action(Back)')        
    else:
        xbmc.executebuiltin('Action(Back)')        

    xbmc.executebuiltin('Content.refresh')
    ver_canais(params)        


def muda_mac(params):
       
    try:
        servidor2 = myaddon.getSetting('ser')
        macant= myaddon.getSetting('mac2')
        escolhido= myaddon.getSetting('escolhido')
    except:
        servidor2='pfducjrm'
    if escolhido=='Arquivo_LOCAL':
        xbmc.executebuiltin('XBMC.Notification(Arquivo local, arquivo local funciona com um único MAC. Se quiser alterar o seu MAC, adicione uma nova linha ao ficheiro local. , 8000)')                        
        xbmc.executebuiltin('Content.Refresh')
        xbmc.executebuiltin('Action(Back)')
    
    else:

        try:    
            mac1 = str(urllib2.urlopen(urllib2.Request("https://pastebin.com/raw/"+servidor2)).read())
            mac=""
            mac=re.findall('(00:.*?79:.*?........)', mac1)
            portal=re.findall('portal"(.*?)"', mac1.lower())[0]
            dialog = xbmcgui.Dialog()
            ret = dialog.select('MAC ACTUAL: [ '+str(escolhido)+' # '+str(macant)+' ]', ['Alteração MAC', 'Continue com MAC '+macant])
            lists = ['sim','não']
    
            categorias= lists[ret]
                
            if 'sim' in categorias:
                newmac=''
            
                selectable="Escolha um MAC aleatório"
                for mc in mac:                                    
                        selectable=selectable+','+str(mc)
                
                lista_macs=selectable.split(",")
                ret=dialog.select('Escolha um MAC :',lista_macs)

                if ret==1:
                    random.seed()
                    while newmac == '' or not newmac:
                        newmac = random.choice(mac)                      
                else:
                    if ret==-1:
                        newmac=macant
                    else:
                        newmac=mac[ret-1]

                if newmac!=macant:
                        myaddon.setSetting('mac2',newmac)
                        xbmc.executebuiltin('XBMC.Notification( MAC nou, ' +newmac+ ', 8000)')                        
    
        except:
                xbmc.executebuiltin('XBMC.Notification( Erro MAC Novo, Continue com' +macant+ ', 8000)')    
                xbmc.executebuiltin('Action(Back)')        

        xbmc.executebuiltin('Content.refresh')
        ver_canais(params)


def paginar_canais(params):
    
    ids = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
    title=params.get('title')
    tit=title.replace('mintcream','blue')
    plugintools.add_item( title=tit, thumbnail = fanny, fanart=fanny ,folder=False,isPlayable=False )   
    for i in range(1,5):
        vpagina=str(i*10)
        pagina=str(i)
        plugintools.add_item( action="canal_por_pagina", title="Pagina: "+pagina, thumbnail = vpagina, fanart=fanny ,plot=token,page=mac,extra=portal,url=ids,folder=True )   
    
    plugintools.add_item( action="todos_os_canais", title="Lista Completa (todas as páginas)", thumbnail = vpagina, fanart=fanny ,plot=token,page=mac,extra=portal,url=ids,folder=True )   

def canal_por_pagina(params):

    vpagina = params.get("thumbnail")
    ids = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
    headers = '{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="'+mac+'"; stb_lang=pt; timezone=Europe/portugal","Authorization": "Bearer "'+token+'}'
  
    pn=int(vpagina)-9  
    count=int(vpagina);pn=pn;data=[]
    while pn <= int(count):
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=pt; timezone=Europe/portugal","Authorization": "Bearer "+token}
        page=portal+'portal.php?type=itv&action=get_ordered_list&genre='+ids+'&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(pn)+'&JsHttpRequest=1-xml';source=requests.get(page, headers=headers).content.decode('ascii','ignore')
        data +=re.findall('("id":".*?","name":".*?".*?"ch_id":".*?")',str(source));pn +=1
        
    url=data
    
    guardar_favs=myaddon.getSetting('favs')
    favoritos = xbmc.translatePath('special://home/userdata/favourites.xml')
    
    pr0n=myaddon.getSetting('pr0n')
    plugintools.add_item(title='[COLOR white]-=========================-[/COLOR]',folder=False, isPlayable=False)   
    plugintools.add_item(title='[COLOR blue]ACTUAL [ '+myaddon.getSetting('escolhido')+' # '+mac+' ][/COLOR]',folder=False, isPlayable=False)   
    plugintools.add_item(title='[COLOR white]-=========================-[/COLOR]',folder=False, isPlayable=False)   
    
    
    if guardar_favs=="true":
        try:            
            f = open(favoritos,'r')
            favoritoss = f.read()
            f.close()
        except:         
            f = open(favoritos,'w+')
            f.write('</favourites>')
            f.close()
            
    head='[COLOR red]Obtendo lista de canais[/COLOR]'
    pb  = xbmcgui.DialogProgress()
    pb.create(head,'')   
    i=0
    for generos in url: 
        i=i+1
        patron = plugintools.find_single_match(generos,'"id":".*?","name":"(.*?)".*?"ch_id":"(.*?)"')
        canal=patron[1]
        titulo=patron[0]
        
        tit=colorea(titulo)
        pb.update(i,'Canal '+tit) 
        if  not('adult' in titulo.lower() and pr0n=="false"):    
            
                  
            plugintools.add_item( action="reproduzir_canal",extra=portal,url=canal,page=mac,plot=params.get("plot"),title=tit, thumbnail = params.get("thumbnail"), fanart= fanny,folder=False,  isPlayable = True ) 
            
            if guardar_favs=="true":
                cmd='plugin://plugin.video.fenix-mac/?action=reproduzir_canal'+'&title='+urllib.quote(titulo,safe='')+'&url='+str(canal)+'&thumbnail=10'+'&plot='+urllib.quote(token,safe='')+'&extra='+urllib.quote(portal,safe='')+'&page='+urllib.quote(mac,safe='')
                try:
                    if not canal in unicode(favoritos, 'utf-8'):
                        favourite(titulo,'10',cmd)
                except:
                    pass
    pb.close()
    
def todos_os_canais(params):

    vpagina = params.get("thumbnail")
    ids = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
    
    guardar_favs=myaddon.getSetting('favs')
    favoritos = xbmc.translatePath('special://home/userdata/favourites.xml')
    if guardar_favs=="true":
        try:
            f = open(favoritos,'r');favs = f.read();f.close()
        except:
            f = open(favoritos,'w+');f.write('</favourites>');f.close()
   
    pr0n=myaddon.getSetting('pr0n')
    plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False)   
    plugintools.add_item(title='[COLOR blue]ACTUAL [ '+myaddon.getSetting('escolhido')+' ][/COLOR]',folder=False, isPlayable=False)   
    plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False)   
    head='Descarregue a lista de canais'
    pb  = xbmcgui.DialogProgressBG()    
    pb.create(head,'')        
    progreso=0
      
    for i in range(1,5):
        vpagina=i*10
        pagina=str(i)
        
        headers = '{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="'+mac+'"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "'+token+'}'
    
        pn=vpagina-9  
        count=i*10;pn=pn;data=[]
        while pn <= count:
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
            page=portal+'portal.php?type=itv&action=get_ordered_list&genre='+ids+'&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(pn)+'&JsHttpRequest=1-xml';source=requests.get(page, headers=headers).content.decode('ascii','ignore')
            data +=re.findall('("id":".*?","name":".*?".*?"ch_id":".*?")',str(source));pn +=1

        url=data
        total=len(data)
        c=1 
        for generos in url: 
            
            patron = plugintools.find_single_match(generos,'"id":".*?","name":"(.*?)".*?"ch_id":"(.*?)"')
            canal=patron[1]
            titulo=patron[0]

            tit=colorea(titulo)

            if  not('adult' in titulo.lower() and pr0n=="false"):                                    
            
                plugintools.add_item( action="reproduzir_canal",extra=portal,url=canal,page=mac,plot=params.get("plot"),title = tit, thumbnail = params.get("thumbnail"), fanart= fanny,folder=False,  isPlayable = True )                                                 
                
                if guardar_favs=="true":
                    cmd='plugin://plugin.video.fenix-mac/?action=reproduzir_canal'+'&title='+urllib.quote(titulo,safe='')+'&url='+str(canal)+'&thumbnail=10'+'&plot='+urllib.quote(token,safe='')+'&extra='+urllib.quote(portal,safe='')+'&page='+urllib.quote(mac,safe='')
                    try:
                        if not canal in unicode(favs, 'utf-8'):
                            favourite(titulo,'10',cmd)
                    except:
                        pass

            progreso=str(int(round((c/total)*100)))                
            pb.update(int(progreso),heading=head+' '+progreso+'%',message='Carregue o canal '+tit+' na página '+str(i)+' '+str(c)+'/'+str(total))    
            c=c+1
                

    pb.close()

def colorea(titulo):

    if  'romania' in titulo.lower() or 'rom' in titulo.lower() or 'EU -RO' in titulo or 'roumania' in titulo.lower():               
        color='darkorange'                                             
    else:
        if 'crime' in titulo.lower():
            color='springgreen'
        else:
            if 'axn' in titulo.lower()  or 'accion' in titulo.lower() or 'estrenos'  in titulo.lower() or 'historia'  in titulo.lower() or 'odisea'  in titulo.lower() or 'discovery'  in titulo.lower():
                    color='deeppink'
            else:        
                if 'adult' in titulo.lower() or 'xxx' in titulo.lower() or 'porn' in titulo.lower():
                    color='red'
                else:
                    color='mintcream'
    
    return '[COLOR '+color+']'+titulo+'[/COLOR]'

def reproduzir_canal(params):
    s=''
    canal = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
   
    headers =headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    url=portal+'portal.php?type=itv&action=create_link&cmd=http://localhost/ch/'+canal+'_&series=&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml'

    try:       
        source=requests.get(url, headers=headers).text
        
        fuente=re.findall('"cmd":"ffmpeg (.*?)"',source )[0]
        fuente= fuente.replace("\\", "")
        
        url=fuente
    
        plugintools.play_resolved_url(url)
    except:
        xbmc.executebuiltin('XBMC.Notification(Erro de play, ' +str(url)+ ', 8000)')            
     
    
def favourite(name,thumb,cmd):
    result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"media", "path":"%s", "thumbnail":"%s"}, "id": 1}' % (name, cmd, thumb))

def linkdirecto(params):
    url = params.get("url")    
    plugintools.play_resolved_url(url)      


def carrega_servidores(params):
    donde=str(params.get('extra'))
    head='Carregar lista de canais '+str(donde)
    pb  = xbmcgui.DialogProgressBG()    
    pb.create(head,'')     
    
    ficheiro = translate('special://home/userdata/addon_data/plugin.video.fenix-mac/'+donde+'_servidores.dat')

    try:
        f=open(ficheiro,'r')        
        servidores=f.readlines()
        linhas=len(servidores)
    except:
        f=open(ficheiro,'w+')        
        f.close()
        f=open(ficheiro,'r')        
        servidores=f.readlines()
        linhas=len(servidores)
        xbmc.executebuiltin('XBMC.Notification(Não existe nenhum ficheiro original , ficheiro: '+str(donde)+', 8000)')          
        xbmc.executebuiltin('Action(Back)')
    i=1
    lista_nomes=''
    lista_macs=''
    selectable=''
    #colors=['red','green','orange','blue','pink','chocolate','darkorange','magenta']
    for servidor in servidores:
        try:      
            
            mac=re.findall('#(00:.*?79:.*?........)', servidor)            
            portal=re.findall('portal"(.*?)"', servidor.lower())
            if portal:
                
                pb.update(int(round(i/linhas)*100),head,str(servidor))
                  
                #color=random.choice(colors)
                if i % 2 == 0:
                    color='white'
                else:
                    color='yellow'    

                if lista_nomes=='':
                    lista_nomes=portal[0]
                    lista_macs=mac[0]
                    selectable='[COLOR '+color+']'+str(i)+'::'+portal[0]+'#'+mac[0]+'[/COLOR]'
                else:
                    lista_nomes=lista_nomes+','+portal[0]
                    lista_macs=lista_macs+','+mac[0]
                    selectable=selectable+',[COLOR '+color+']'+str(i)+' :: '+portal[0]+' # '+mac[0]+'[/COLOR]'
                i+=1   
        except:
            xbmc.executebuiltin('XBMC.Notification([COLOR red]ERRO[/COLOR] ao obter dados , SERVIDOR: '+str(servidor)+', 8000)')               
                           
    f.close()
    pb.close()
    
    dialog = xbmcgui.Dialog()    
    select_one=selectable.split(',')
    retorno = dialog.select('Escolha PORTAL+MAC', select_one)
    
    
    if str(retorno)=='-1':   
        xbmc.executebuiltin('Action(Back)')   
        #xbmc.executebuiltin('XBMC.Notification([COLOR red][/COLOR] obteniendo datos , SERVIDOR: '+str(servidor2)+', 8000)')                   
    else:
        l_n=lista_nomes.split(',')
        l_m=lista_macs.split(',')
        
        servidor2=str(l_n[retorno])
        mac2=str(l_m[retorno])
        
        myaddon.setSetting('mac2',mac2)
        myaddon.setSetting('portal2',servidor2)
        myaddon.setSetting('escolhido','Arquivo_LOCAL')
        myaddon.setSetting('ser',servidor2)
        
        # xbmc.executebuiltin('XBMC.Notification([COLOR red]Cancelo[/COLOR] Cancelado , No se ha escolhido un servidor, 8000)')                   
    xbmc.executebuiltin('Content.refresh')    
    ver_canais(params)      
        

def guarda_servidores(params):
    donde=str(params.get('extra'))    
    head='Salvar Servidores '
    pb  = xbmcgui.DialogProgressBG()    
    pb.create(head,'') 
    lists=myaddon.getSetting('lista').split(',')
    cuantos=len(lists)
    lista_servidores=myaddon.getSetting('lista_servidores').split(',')
    ficheiro = translate('special://home/userdata/addon_data/plugin.video.fenix-mac/'+donde+'_servidores.dat')        
    f=open(ficheiro,'w')            
    i=1
    for servidor in lists:
        try:      
            percent=str(int(round(100*i/cuantos)))
            # xbmc.executebuiltin('XBMC.Notification([COLOR red]Leyendo servidor[/COLOR] , SERVIDOR: '+str(servidor)+' '+str(i)+'/'+str(cuantos)+' '+percent+'%, 8000)')          
            mac1 = str(urllib2.urlopen(urllib2.Request("https://pastebin.com/raw/"+servidor)).read())
            
            pb.update(int(percent),head,str(percent)+'% '+str(lista_servidores[i]))
            macs=""
            macs=re.findall('(00:.*?79:.*?........)', mac1)            
            portal=re.findall('portal"(.*?)"', mac1.lower())[0]
            for mac in macs:
                f.write('portal"'+str(portal)+'"#'+str(mac)+'\n')
                
        except:
            # xbmc.executebuiltin('XBMC.Notification([COLOR red]ERROR[/COLOR] obteniendo datos , SERVIDOR: '+str(servidor)+', 8000)')               
            xbmc.log('Erro na obtenção de dados SERVIDOR: '+str(servidor))
            pass
        i=i+1     
    f.close()
    pb.close()
    xbmc.executebuiltin('XBMC.Notification([COLOR red]Arquivo de dados '+donde+'[/COLOR] , Dados guardados SERVIDOR no arquivo LOCAL , 8000)')          
    
    xbmc.executebuiltin('Content.refresh')
    #xbmc.executebuiltin("Action(Back)")
    #main_list(params)

def novo_servidor(params):
   
    keyboard = xbmc.Keyboard("","Servidor Pastebin:")
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        servidor = keyboard.getText()
        keyboard = xbmc.Keyboard("","Nome Servidor:")
        keyboard.doModal()
        if (keyboard.isConfirmed()):        
            name= keyboard.getText()
            lista=myaddon.getSetting('lista')+','+str(servidor)
            myaddon.setSetting('lista',lista)
            myaddon.setSetting('lista_servidores',myaddon.getSetting('lista_servidores')+','+name)
            xbmc.executebuiltin('XBMC.Notification(Servidor PASTEBIN , Dados guardados SERVIDOR Pastebin, 8000)')          

def novo_servidor_file(params):
    donde = params.get('extra')
    ficheiro = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.fenix-mac/'+donde+'_servidores.dat')        
    keyboard = xbmc.Keyboard("","Servidor:Port")
    keyboard.doModal()
    #if (keyboard.isConfirmed()):
        #puerto = keyboard.getText()
        #keyboard = xbmc.Keyboard("","Puerto:")
        #keyboard.doModal()
    if (keyboard.isConfirmed()):        
        servidor=keyboard.getText()
        keyboard = xbmc.Keyboard("","MAC:")
        keyboard.doModal()
        if (keyboard.isConfirmed()):        
            mac= keyboard.getText()                
            f=open(ficheiro,'a')
            f.write('\n'+'portal"'+servidor+'/"'+'#'+mac)
            f.close()
            xbmc.executebuiltin('XBMC.Notification(Servidor Arquivo_LOCAL , Dados guardados SERVIDOR no arquivo LOCAL, 8000)')

def guiatv ( params ):
    url = params.get("url")  
    
    header = [ ]
    header.append ( [ "User-Agent" , "Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0" ] )
    read_url , read_header = plugintools . read_body_and_headers ( url , headers = header )
    
    url = read_url.strip ( )    
    
    matches = re.findall(r'(?s)class="rede">.*?<a href="([^"]+)" title="Programacão ([^"]+)".*?|<div class="(agora)">\s*(.*?)<.*?|<div class="logo">\s*<span class="date">(\d+:\d+)<\/span>\s*([^<]+)|<div class="mais tarde">\s*<span class="date">(\d+:\d+)<\/span>\s*([^<]+)\s*|<span class="restante"><\/span>\s*<a class="mais" href="([^"]+)"><span>(Grelha completa)<\/span',url)
    
    for url, channel, nowhour, now, laterhour, later, morelaterhour, morelater, url2, completed in matches:
        nowhour = "\x20" +nowhour
        if url:
            url = url
        else:
            if url2:
                url = url2    
        title = "[B][COLOR snow]" + channel + "[/COLOR][/B]\x20" +' -'+nowhour + "\x20" +now+' '+laterhour + "\x20" +later+ morelaterhour +' '+morelater + "[COLOR orange]" + completed + "[/COLOR]"
        plugintools.add_item ( action = "parse_guiatv" , title = title, url = url, thumbnail=thmb_guia, fanart=fanart_guia, folder = True)
        

def parse_guiatv ( params ):
    url = params.get("url")  
    header = [ ]
    header . append ( [ "User-Agent" , "Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0" ] )
    read_url , read_header = plugintools . read_body_and_headers ( url , headers = header )
    url = read_url . strip ( )    
    matches = re.findall(r'{"@context":"[^"]+","@type":"Event","name":"(\d+:\d+ - [^"]+)","description":"([^"]+)"',url)
    for title, desc in matches: 
        plugintools . add_item ( action = "" , title = title, url = url, thumbnail=thmb_guia, fanart=fanart_guia,folder = False)

run()